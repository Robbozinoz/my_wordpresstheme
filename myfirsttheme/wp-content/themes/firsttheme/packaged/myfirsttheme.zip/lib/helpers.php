<?php

//---Site wide function for extarcting a variety of post meta
//---Enusre fnuction name is unique for submission to theme markets, avoiding conflicts
//---IMPORTANT-----URL/Htmla and Attributes escaped as standard

if (!function_exists('myfirsttheme_post_meta')) {
    function myfirsttheme_post_meta()
    {
        /*---Addition of printf function to translate strings in function---*/
        /*translators: %s: Post date*/
        printf(
            esc_html__('Posted on %s', 'myfirsttheme'),
            '<a href="' . esc_url(get_permalink()) . '">
                <time datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time></a>'
        );
        /*translators: %s: Author name*/
        printf(
            esc_html__(' By %s', 'myfirsttheme'),
            '<a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . esc_html(get_the_author()) .
                '</a>'
        );
    }
}

//Concatenated function for site wide Read more links
function myfirsttheme_readmore_link()
{
    echo '<a class="c-post__readmore" href="' . esc_url(get_permalink()) . '" title="' . the_title_attribute(['echo' => false]) . '">';

    /*translators: %s: Post title*/
    printf(
        //Strip the span tags and add them to the array of allowed html alongwith any classes to be used
        wp_kses(
            __('Read More  <span class="u-screen-reader-text">About: %s</span>', 'myfirsttheme'),
            [
                'span' => [
                    'class' => []
                ]
            ]
        ),
        get_the_title()
    );
    echo '</a>';
}

//Function to add an anchor tag which adds actions to delete post
function myfirsttheme_delete_post()
{
    $url = add_query_arg([
        'action' => 'myfirsttheme_delete_post',
        'post' => get_the_ID(),
        'nonce' => wp_create_nonce('myfirsttheme_delete_post' . get_the_ID())
    ], home_url());

    //if the user has permission to delete display the "Delete" button
    if (current_user_can('delete_post', get_the_ID())) {
        return "<a href='" . esc_url($url) . "'>" . esc_html__('Delete Post', 'myfirsttheme') . "</a>";
    }
}
