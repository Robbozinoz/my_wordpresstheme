<?php

function myfirsttheme_sidebar_widgets()
{
    register_sidebar(array(
        'id' => 'primary-sidebar',
        'name' => esc_html__('Primary Sidebar', 'myfirsttheme'),
        'description' => esc_html__('This sidebar appears in the blog posts page', 'myfirsttheme'),
        'before_widget' => '<section id="%1$s" class="c-sidebar-widget u-margin-bottom-20 %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h5>',
        'after_title' => '</h5>'
    ));
}

//Get and check customiser function to addd controls for footer layout
$footer_layout = sanitize_text_field(get_theme_mod('myfirsttheme_footer_layout', '3,3,3,3'));
//Extarct user errors in customiser field
$footer_layout = preg_replace('/\s+/', '', $footer_layout);
$columns = explode(',', $footer_layout);
$footer_bg = myfirsttheme_sanitize_footer_bg(get_theme_mod('myfirsttheme_footer_bg', 'dark'));
//Set theme of sidebar area for footer
if ($footer_bg == 'light') {
    $widget_theme = 'c-footer-widget--dark';
} else {
    $widget_theme = 'c-footer-widget--light';
}

foreach ($columns as $i => $column) {
    register_sidebar(array(

        'id' => 'footer-sidebar-' . ($i + 1),
        'name' => sprintf(esc_html__('Footer Widgets Column %s', 'myfirsttheme'), $i + 1),
        'description' => esc_html__('Footer widgets', 'myfirsttheme'),
        'before_widget' => '<section id="%1$s" class="c-footer-widget' . $widget_theme . ' %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h5>',
        'after_title' => '</h5>'
    ));
}

add_action('widgets_init', 'myfirsttheme_sidebar_widgets');
