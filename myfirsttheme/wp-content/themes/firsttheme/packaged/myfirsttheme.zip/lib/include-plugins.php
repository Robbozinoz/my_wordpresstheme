<?php

//Load the class for use
require_once get_template_directory() . '/lib/class-tgm-plugin-activation.php';

add_action('tgmpa_register', 'myfirsttheme_register_required_plugins');

function myfirsttheme_register_required_plugins()
{
    //Array of required pugins
    $plugin = array(
        array(
            'name' => 'myfirsttheme metaboxes',
            'slug' => 'myfirsttheme-metaboxes',
            'source' => get_template_directory_uri() . '/lib/plugins/myfirsttheme-metaboxes.zip',
            'required' => true,
            'version' => '1.0.0',
            'force_activation' => false,
            'force_deactivation' => false,
        )
    );

    //Array of configuration arguments for class
    $config = array();

    tgmpa($plugin, $config);
}
