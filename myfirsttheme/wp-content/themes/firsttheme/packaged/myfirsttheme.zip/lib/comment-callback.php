<?php

function myfirsttheme_comment_callback($comment, $args, $depth)
{ ?>
    <li id="comment-<?php comment_ID(); ?>" <?php comment_class(['c-comment', $comment->comment_parent ? 'c-comment--child' : '']) ?>>

        <article id="div-comment-<?php comment_ID(); ?>" class=" c-comment__body">
            <?php echo get_avatar($comment, 100, false, false, array('class' => 'c-comment__avatar')); ?>
            <?php edit_comment_link(esc_html__('Edit Comment', 'myfirsttheme'), '<span 
            class="c-comment__edit-link">', '</span>'); ?>

            <div class="c-comment__content">
                <div class="c-comment__author">
                    <?php echo get_comment_author_link($comment); ?>
                </div>
                <!--Display the time of the comment-->
                <a href="<?php echo esc_url(get_comment_link($comment, $args)) ?>" class="c-comment__time">
                    <time datetime="<?php comment_time('c') ?>">
                        <!--Translate the the time for internationalisation-->
                        <?php
                            printf(esc_html__('%s ago', 'myfirsttheme'), human_time_diff(
                                get_comment_time('U'),
                                current_time('U')
                            ));
                            ?>
                    </time>

                    <!--Display the content of the comment-->
                    <?php if ($comment->comment_approved == '0') { ?>
                        <p class="c-comment__awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'myfirsttheme'); ?></p>
                    <?php } ?>

                    <?php comment_text() ?>

                    <?php comment_reply_link(array(
                            'depth' => $depth,
                            'max_depth' => $args['max_depth'],
                            'add_below' => 'div-comment',
                            'before' => '<div class="c-comment__reply-link">',
                            'after' => '</div>'
                        ));
                        ?>
                </a>
            </div>
        </article>
    <?php } ?>