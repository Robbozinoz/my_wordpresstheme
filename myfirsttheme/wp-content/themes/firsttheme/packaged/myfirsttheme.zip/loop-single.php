<?php if (have_posts()) { ?>
    <?php while (have_posts()) { ?>
        <?php the_post(); ?>
        <?php get_template_part('template-parts/post/content', get_post_format()); ?>

        <?php
                //Get the Author Bio checkbox result from the customisor
                if (get_theme_mod('myfirsttheme_display_author_info', true)) { ?>
            <?php get_template_part('template-parts/single/author', ''); ?>
        <?php } ?>

        <?php get_template_part('template-parts/single/navigation', ''); ?>

        <?php
                if (comments_open() || get_comments_number()) {
                    comments_template();
                }
                ?>
    <?php } ?>
<?php } else { ?>
    <?php get_template_part('template-parts/post/content', 'none'); ?>
<?php } ?>