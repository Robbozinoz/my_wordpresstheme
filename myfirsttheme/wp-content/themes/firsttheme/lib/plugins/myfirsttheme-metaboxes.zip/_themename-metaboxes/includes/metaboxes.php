<?php

//Function to create the metabox scaffold
function myfirsttheme_add_meta_box()
{
    add_meta_box('myfirsttheme_post_metabox', esc_html__('Post Settings'), 'myfirsttheme_post_metabox_html', 'post', 'normal', 'default');
}

add_action('add_meta_boxes', 'myfirsttheme_add_meta_box');

//Function to control the html output of the metabox
function myfirsttheme_post_metabox_html($post)
{
    //Variable for the Post setting subtitle value
    $subtitle = get_post_meta($post->ID, '_myfirsttheme_post_subtitle', true);

    //Variable for the drop down menu field value
    $layout = get_post_meta($post->ID, ' _myfirsttheme_post_layout', true);

    //Add a nonce to the save post mneta function
    wp_nonce_field('myfirsttheme_update_post_metabox', 'myfirsttheme_update_post_nonce');
    ?>
    <p>
        <label for="">
            <?php esc_html_e('Post Subtitle', 'myfirsttheme-metaboxes'); ?>
        </label>
        <br />
        <!--Add value of the Post Subtitle field to the input and escape-->
        <input class="widefat" type="text" name="myfirsttheme_post_subtitle_field" id="myfirsttheme_post_metabox_html" value="<?php echo esc_attr($subtitle); ?>" />
    </p>
    <p>
        <label for="myfirsttheme_post_layout_field"><?php esc_html_e('Layout', 'myfirsttheme-metaboxes'); ?></label>
        <select name="myfirsttheme_post_layout_field" id="myfirsttheme_post_layout_field" class="widefat">
            <option <?php selected($layout, 'full'); ?> value="full"><?php esc_html_e('Full Width', 'myfirsttheme-metaboxes'); ?></option>
            <option <?php selected($layout, 'sidebar'); ?> value="sidebar"><?php esc_html_e('Post with Sidebar', 'myfirsttheme-metaboxes'); ?></option>
        </select>
    </p>
<?php
}

//Function to save the post content in the database - wp does not do this automatically
function myfirsttheme_save_post_metabox($post_id, $post)
{
    //Check dynamically for the post type and reuse in the $edit-cap variable
    $edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
    if (!current_user_can($edit_cap, $post_id)) {
        return;
    }
    //Check if the nonce in myfirsttheme_post_metabox_html exists and is valid
    if (!isset($_POST['myfirsttheme_update_post_nonce']) || 'myfirsttheme_update_post_metabox') {
        return;
    }

    //Check that the meta key exists in the global post variable
    if (array_key_exists('myfirsttheme_post_subtitle_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_myfirsttheme_post_subtitle',
            //Clean the value place in the databse for use in the $sibtitle variable
            sanitize_text_field($_POST['myfirsttheme_post_subtitle_field'])
        );
    }

    //Check that the meta key for post layout dropdownexists in the global post variable
    if (array_key_exists('myfirsttheme_post_layout_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_myfirsttheme_post_layout',
            //Clean the value place in the databse for use in the $sibtitle variable
            sanitize_text_field($_POST['myfirsttheme_post_layout_field'])
        );
    }
}

add_action('save_post', 'myfirsttheme_save_post_metabox', 10, 2);
